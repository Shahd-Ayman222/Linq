﻿using day10_G01;
using System;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.WebSockets;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.Intrinsics.X86;
using System.Security.Cryptography;
using System.Threading;
using static day10_G01.ListGenerators;

namespace Linq_EFDay01
{
    internal class Program
    {


        static void Main()
        {
            #region Q1
            //q1
            //var Products = ProductList.
            //    Where(p => p.UnitsInStock == 0)

            //foreach (var Product in Products)
            //{
            //    Console.WriteLine(Product);
            //}
            ////-----------
            //var Products = ProductList.
            //    Where(p => p.UnitsInStock > 0 && p.UnitPrice > 3)
            //    .ToArray();
            //foreach (var Product in Products)
            //{
            //    Console.WriteLine(Product);
            //}
            //-----------
            //string[] arr = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
            //var res = arr
            //   .Where(x => x.Length < Array.IndexOf(arr, x)).ToList();
            //foreach (var x in res)
            //{
            //    Console.WriteLine(x);
            //}
            #endregion

            #region Q2
            // 1- LINQ - Element Operators
            //Use ListGenerators.cs
            //var res = ProductList.
            //    Where(p => p.UnitsInStock == 0)
            //    .First();
            //Console.WriteLine(res);
            //-------------
            // 2- 
            //var res = ProductList.
            //    Where(p => p.UnitPrice > 1000).FirstOrDefault();
            //Console.WriteLine(res);

            //-----------
            // 3
            //int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //var res2 = Arr
            //    .OrderBy(x => x)
            //    .Where(x => x > 5)
            //    .Skip(1)
            //    .Take(1);
            //    foreach (var x in res2)
            //    {
            //        Console.WriteLine(x);
            //    }
            //}
            //-----------------------
            #endregion

            #region Q3
            //1
            //int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //var res = Arr
            //    .Where(x => x % 2 != 0)
            //    .Count();
            //------------------
            //var Customers = CustomerList;
            //var Orders = Customers
            //    .Select(c => new
            //    {
            //        CustomerName = c.Name,
            //        OrderCount = c.Orders.Count()
            //    });
            //foreach (var customer in Orders)
            //{
            //    Console.WriteLine(customer);
            //}
            //var products = ProductList;
            //var res = products
            //    .GroupBy(p => p.Category)
            //    .Select(g => new
            //    {
            //        Category = g.Key,
            //        Count = g.Count()
            //    });
            //foreach (var i in res)
            //{
            //    Console.WriteLine(i);
            //}
            //int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //var res = Arr.Aggregate((acc, n) => acc + n);
            //Console.WriteLine(res);
            ///===================
            //var sum = Arr.
            //    Sum(x => x);
            //Console.WriteLine(sum);
            //-------------------
            //var Products = ProductList;
            //var filter = Products
            //    .GroupBy(p => p.Category)
            //    .Select(g => new
            //    {
            //        Category = g.Key,
            //        SumUnitinstock = g.Sum(p => p.UnitsInStock)
            //    });
            //foreach (var product in filter)
            //{
            //    Console.WriteLine(product);
            //}
            //---------------------------
            //var res = ProductList
            //   .GroupBy(p => p.Category)
            //   .Select(g => new
            //   {
            //       Category = g.Key,
            //       minprice = g.Min(p => p.UnitPrice)
            //   });
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //---------------------
            //var res =from p in ProductList
            //group p by p.Category into g
            //let minPrice = g.Min(p => p.UnitPrice)
            //from p in g
            //where p.UnitPrice == minPrice
            //select p;
            //foreach (var item in res)
            // {
            //    Console.WriteLine(item);
            // }
            //-------------------------
            //var res = ProductList
            //  .GroupBy(p => p.Category)
            //  .Select(g => new
            //  {
            //      Category = g.Key,
            //      minprice = g.Max(p => p.UnitPrice)
            //  });
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //-------------------------
            //var res=from p in ProductList
            //group p by p.Category into g
            //let maxPrice = g.Max(p => p.UnitPrice)
            //from p in g
            //where p.UnitPrice == maxPrice
            //select p;
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //-----------------------
            //var res = ProductList
            // .GroupBy(p => p.Category)
            // .Select(g => new
            // {
            //     Category = g.Key,
            //     minprice = g.Average(p => p.UnitPrice)
            // });
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //-------------------------------

            #endregion
            #region Q4
            //1
            //var res = ProductList
            //    .OrderBy(p => p.ProductName, StringComparer.OrdinalIgnoreCase);
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //---------------------------
            //2
            //string[] Arr = { "aPPLE", "AbAcUs", "bRaNcH", "BlUeBeRrY", "ClOvEr", "cHeRry" };
            //var res=Arr.OrderBy(x=>x, StringComparer.OrdinalIgnoreCase);
            //foreach (var item in res)
            //{
            //    Console.Write(item+" ");
            //}
            //-------------------------
            //3
            //var res = ProductList
            //    .OrderByDescending(p => p.UnitPrice);
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //----------------------
            //4
            //            string[] Arr = { "zero","one", "two", "three", "four", "five", "six", "seven", "eight",
            //"nine" };
            //            var res = Arr.OrderByDescending(x => x);
            //            foreach (var item in res)
            //            {
            //                Console.Write(item + " ");
            //            }
            //----------------------------------
            ////5
            //string[] Arr = { "aPPLE", "AbAcUs", "bRaNcH", "BlUeBeRrY", "ClOvEr", "cHeRry" };
            //var res = Arr.OrderByDescending(x => x.Length).ThenByDescending(x => x, StringComparer.OrdinalIgnoreCase);
            //foreach (var item in res)
            //{
            //    Console.Write(item + " ");
            //}
            //-------------------------------------
            //6
            //var res = ProductList
            //    .OrderByDescending(p => p.Category, StringComparer.OrdinalIgnoreCase)
            //    .ThenByDescending(p => p.UnitPrice);
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //------------------------
            //7 Duplicated
            //-------------
            //8
            //            string[] Arr = { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
            //"nine" };
            //            var res = Arr.
            //                Where(x => x[1] == 'i').Reverse();
            //            foreach (var item in res)
            //            {
            //                Console.WriteLine(item);
            //            }
            //---------------------------------

            #endregion
            #region Q5
            //1
            //var res = ProductList
            //    .Select(p => p.ProductName).ToList();
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //---------------
            //2
            //string[] words = { "aPPLE", "BlUeBeRrY", "cHeRry" };
            //var res = words.Select(x => new
            //{
            //    Upper = x.ToUpper(),
            //    Lower = x.ToLower()
            //});
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //-----------------
            //3
            //var res = ProductList
            //    .Select(p => new
            //    {
            //        p.ProductID,
            //        p.ProductName,
            //        p.Category,
            //        Price = p.UnitPrice
            //    });
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            ////----------------------
            ///4
            //int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //var res = Arr
            //    .Select((x, i) => new
            //    {
            //        index = i,
            //        result = x == i

            //    });
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //------------------------
            //5
            //int[] numbersA = { 0, 2, 4, 5, 6, 8, 9 };
            //int[] numbersB = { 1, 3, 5, 7, 8 };
            //var res = numbersA.SelectMany(a => numbersB
            //    .Where(b => a < b)
            //    .Select(b => new
            //    {
            //        A = a,
            //        B = b
            //    }));
            //foreach (var item in res)
            //{
            //    Console.WriteLine($"{item.A} is less than {item.B}");
            //}
            //------------------
            //6
            //var res = CustomerList
            //    .SelectMany(c => c.Orders,
            //    (c, o) => new
            //    {
            //        o.Total,
            //        c.Name
            //    }
            //    ).Where(o => o.Total < 500);
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //--------------------------
            //7
            //var res = CustomerList
            //    .SelectMany(c => c.Orders,
            //    (c, o) => new
            //    {
            //        o.Total,
            //        o.OrderDate,
            //        c.Name
            //    }
            //    ).Where(o => o.OrderDate.Year>=1998);
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}



            #endregion

            #region Q6
            //1
            //int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //var res = Arr
            //    .Count(x => x % 2 != 0);
            //Console.WriteLine(res);
            //--------------------------
            //2
            //var Customer = CustomerList;
            //var res = Customer
            //.Select(c => new
            //{
            //    Name = c.Name,
            //    count = c.Orders.Count(),
            //});
            //foreach (var c in res)
            //{
            //    Console.WriteLine(c);
            //}
            //----------------
            //3
            //var res = ProductList
            //   .GroupBy(p => p.Category).Select(g => new
            //   {
            //       categoryname = g.Key,
            //       count = g.Count()

            //   });
            //foreach (var c in res)

            //{
            //    Console.WriteLine(c);
            //}
            //----------------
            //4
            //int[] Arr = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //var res = Arr.Sum(x => x);
            //Console.WriteLine(res);
            //----------------
            //6
            //var res = ProductList
            //   .GroupBy(p => p.Category).Select(g => new
            //   {
            //       categoryname = g.Key,
            //      sum = g.Sum(p=>p.UnitsInStock)

            //   });
            //foreach (var item in res) {
            //    Console.WriteLine(item);
            //}
            //------------
            //8
            // var res = ProductList
            //.GroupBy(p => p.Category).Select(g => new
            //{
            //    categoryname = g.Key,
            //    min = g.Min(p => p.UnitPrice)

            //});
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //-------------
            //9
            // var res =
            //from p in ProductList
            //group p by p.Category into g
            //let cheapest = g.OrderBy(p => p.UnitPrice).FirstOrDefault()
            //select new
            // {
            //Category = g.Key,
            //Product = cheapest
            // };
            // foreach (var item in res)
            // {
            //     Console.WriteLine(item);
            // }
            //--------------------
            //11
            // var res = ProductList
            //.GroupBy(p => p.Category).Select(g => new
            //{
            //    categoryname = g.Key,
            //    max = g.Max(p => p.UnitPrice)

            //});
            // foreach (var item in res)
            // {
            //     Console.WriteLine(item);
            // }
            //----------------------
            //12
            //var res = ProductList
            //.GroupBy(p => p.Category).Select(g => new
            //      {
            //    categoryname = g.Key,
            //    Product = g.OrderByDescending(p => p.UnitPrice)
            //         .FirstOrDefault()
            //     });
            // foreach (var item in res)
            //  {
            //      Console.WriteLine(item);
            //  }
            //-----------------------
            //14
            //  var res = ProductList
            //.GroupBy(p => p.Category).Select(g => new
            //  {
            //  categoryname = g.Key,
            //  Avg = g.Average(p => p.UnitPrice)
            // });
            //  foreach (var item in res)
            //  {
            //      Console.WriteLine(item);
            //  }
            #endregion
            //Duplicate sort questions 
            #region Q7
            //1
            //var res = CustomerList
            //    .Where(c=>c.City.Equals("washington", StringComparison.OrdinalIgnoreCase))
            //    .Select(c=> new
            //    {
            //        c.City,
            //        c.Orders,
            //        c.Address

            //    })
            //    .Take(3);
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //----------------
            //2
            //var res = CustomerList 
            //    .Where(c => c.City == "Berlin") //not found  Washington
            //    .SelectMany(c => c.Orders, (c, o) => new
            //    {
            //        c.City,
            //        o.Total,
            //        c.Country,
            //        c.Name,
            //        o.OrderDate
            //    }).Skip(2);
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //------------------------
            //3
            //int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //var res =
            //    numbers.Select((x, i) => new
            //    {
            //        index = i,
            //        n = x
            //    })
            //    .TakeWhile(x => x.n > x.index);
            //foreach (var x in res)
            //{
            //    Console.WriteLine(x);
            //}
            //------------------------------
            //4
            //int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //var res =
            //  numbers.Select((x, i) => new
            //  {
            //      index = i,
            //      n = x
            //  })
            //  .SkipWhile(x => x.n % 3 != 0);
            //foreach (var x in res)
            //{
            //    Console.WriteLine(x);
            //}
            //---------------------------
            //5
            //int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //var res =
            //  numbers.Select((x, i) => new
            //  {
            //      index = i,
            //      n = x
            //  })
            //  .SkipWhile(x =>x.index<=x.n);
            //foreach (var x in res)
            //{
            //    Console.WriteLine(x);
            //}
            #endregion
            #region Q8
            //1
            // var res = CustomerList
            //.Where(c => c.City == "Berlin")
            //.SelectMany(c => c.Orders)
            //.Take(3);
            // foreach (var c in res)
            // {
            //     Console.WriteLine(c);
            // }
            //---------------------
            //2
            // var res = CustomerList
            //.Where(c => c.City == "Berlin") //washinton not found in data
            //.SelectMany(c => c.Orders)
            //.Skip(3);
            // foreach (var c in res)
            // {
            //     Console.WriteLine(c);
            // }
            //------------------------
            //3 duplicated
            //int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };
            //var res =
            //    numbers.Select((x, i) => new
            //    {
            //        index = i,
            //        n = x
            //    })
            //    .TakeWhile(x => x.n > x.index);
            //    foreach (var x in res)
            //    {
            //    Console.WriteLine(x);
            //    }
            //4,5 duplicate
            #endregion
            #region Q9
            //1
            //var res = ProductList
            //    .Where(p => p.UnitsInStock == 0)
            //    .GroupBy(p => p.Category)
            //    .Select(g => new
            //    {
            //        Category = g.Key,
            //        ProductNames = string.Join(", ", g.Select(p => p.ProductName)),
            //        unitinstock = g.Count()
            //    });
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //---------------------
            //var res = ProductList
            //   .GroupBy(p => p.Category)
            //   .Where(g => g.Any(p => p.UnitsInStock == 0))
            //   .Select(g => new
            //   {
            //       Category = g.Key,
            //       ProductNames = string.Join(", ", g.Select(p => p.ProductName)),
            //       unitinstock = g.Count()
            //   });
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //--------------------------
            //3
            //var res = ProductList
            //  .GroupBy(p => p.Category)
            //  .Where(g => g.All(p => p.UnitsInStock > 0))
            //  .Select(g => new
            //  {
            //      Category = g.Key,
            //      ProductNames = string.Join(", ", g.Select(p => p.ProductName)),
            //      unitinstock = g.Count()
            //  });
            // foreach (var item in res)
            //  {
            //    Console.WriteLine(item);
            //  }

            #endregion






        }
    }
}
        









    
   
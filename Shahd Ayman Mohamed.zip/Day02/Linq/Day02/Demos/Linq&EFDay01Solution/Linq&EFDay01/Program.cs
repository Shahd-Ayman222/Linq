﻿using day10_G01;
using System;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.WebSockets;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography;
using System.Threading;
using static day10_G01.ListGenerators;
using static Linq_EFDay01.Program;

namespace Linq_EFDay01
{
    internal class Program
    {
        public static void Main()
        {
            //Q1)
            //var res = ProductList
            //    .OrderByDescending(x => x.UnitPrice)
            //    .Take(3);
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //-----------
            //Q2)
            //n-1 *padge size
            //var res = ProductList
            //    .Skip(5)
            //    .Select(x => x);
            //foreach (var x in res)
            //{
            //    Console.WriteLine(x);

            //}
            //-----------------
            //Q3)
            //var res = ProductList
            //    .Where(p => p.UnitPrice < 25)
            //    .OrderByDescending(p => p.UnitPrice).ToList();
            //foreach (var x in res)
            //{
            //    Console.WriteLine(x);
            //}
            //---------
            //Q4)
            //var res = ProductList
            //    .Where(p => string.Equals(p.Category, "SeaFood", StringComparison.OrdinalIgnoreCase))
            //    .All(p => p.UnitsInStock > 0);
            //Console.WriteLine(res);
            //----------------
            //Q5)
            //int[] ids = { 3, 9, 13, 18 };
            //var res = ids.Contains(9);
            //Console.WriteLine(res);
            //----------------------
            //Q6)
            //var res = ProductList
            //    .GroupBy(p => p.Category)
            //    .Select(p => new
            //    {
            //        CategoryName = p.Key,
            //        Count = p.Count()
            //    }); //instead projection make nested loop
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);

            //}
            //---------------------
            //Q7)
            //var res = ProductList
            //   .GroupBy(g => g.Category);
            //foreach (var group in res)
            //{
            //    Console.Write(group.Key+": ");
            //    foreach (var item in group)
            //    {
            //        Console.Write(item.ProductName+" , ");
            //    }
            //    Console.WriteLine();

            //}
            //-----------------------
            //Q8)
            //var res = ProductList
            //     .GroupBy(p => p.Category)
            //     .Where(p => p.Count() > 3)
            //      .Select(p =>
            //      new
            //      {
            //          Category = p.Key,
            //          Count = p.Count()
            //      });

            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //--------------------------------
            //Q9)
            //var res = from g in CustomerList
            //          from i in g.Orders
            //          group g by g.Country
            //          into g2
            //          select new
            //          {
            //              Country = g2.Key,
            //              Count = g2.Count(),
            //              totalorder = g2.Sum(i => i.Orders.Length)


            //          };
            //       foreach (var item in res)
            //         {
            //            Console.WriteLine(item);
            //          }
            //----------------------
            //Q10)
            //var res = ProductList
            //     .Where(p => p.UnitsInStock > 0)
            //     .Sum(p => p.UnitsInStock);

            //Console.WriteLine(res);
            //--------------------------
            //Q11)
            //var res = ProductList
            //    .OrderByDescending(p => p.UnitPrice).First();
            //    Console.WriteLine(res);
            //var res2 = ProductList
            //  .OrderByDescending(p => p.UnitPrice).Last();
            //Console.WriteLine(res2);
            //--------------------------
            //Q12)
            //var res3 = ProductList
            //   .Select(p => p.Category).Distinct();
            //foreach (var item in res3)
            //{
            //    Console.WriteLine(item);
            //}
            //---------------------
            //Q13)
            //int[] setA = { 1, 3, 5, 7, 9, 11, 13 };
            //int[] setB = { 3, 6, 9, 12, 15, 13 };
            //var res = setA.Except(setB);
            //foreach (int i in res)
            //{
            //    Console.Write(i + " ");
            //}
            //--------------------
            //Q14
            //string[] list1 = { "Germany", "France", "UK", "Spain" };
            //string[] list2 = { "france", "SPAIN", "Italy" };
            //var res = list1.Except(list2,StringComparer.OrdinalIgnoreCase);
            //foreach (var  i in res)
            //{
            //    Console.Write(i +" ");
            //}
            //---------------------
            //Q15)
            //Dictionary<long, Product> dic = ProductList.ToDictionary(p => p.ProductID);
            //var product = dic[18];
            //Console.WriteLine(product.ProductName);
            //-----------------------
            //Q16)
            //var res=ProductList
            //    .First(p=>p.UnitPrice>50);
            //Console.WriteLine(res);
            //-------------------
            //Q17)
            //var res = ProductList
            //    .FirstOrDefault(p => p.UnitPrice > 500);
            //if (res is null) // handle null 
            //{
            //    Console.WriteLine("not found ");
            //}
            //Q18)
            //var res = Enumerable.Range(1, 7).Select(i => new
            //{
            //    i=i,
            //    res=i * 7
            //});
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);
            //}
            //--------------
            //Q19)
            //var res = Enumerable.Range(1, 30).Where(i => i % 2 == 0);

            //foreach (var item in res)
            //{
            //    Console.Write(item+" ");
            //}
            //----------------------
            //Q20)
            //var res = ProductList
            //    .OrderBy(p => p.ProductID)
            //    .Select(p => p.ProductName)
            //    .Take(3)
            //    .Concat(
            //    CustomerList.Select(
            //        c => c.Name).Take(3)
            //    );
            //foreach (var item in res)
            //{
            //    Console.WriteLine(item);

            //}
            //------------------------
            //Q21
            // var res = ProductList
            //.Zip(CustomerList, (p, c) => $"{p.ProductName} sold to {c.Name}");
            // foreach (var item in res)
            // {
            //     Console.WriteLine(item);
            // }












        }
    }
        }

        